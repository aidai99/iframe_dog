=== Plugin Name ===
Contributors: Carseason
Donate link: https://github.com/Carseason/iframe_dog
Tags: iframe
Requires at least: 4.6
Tested up to: 4.9.6
Stable tag: 4.9.6
Requires PHP: 5.6
== Description ==
= 2.4 =
Fix the problem
= 2.0 =
iframe_dog up!
= 1.0 =
iframe_dog up!