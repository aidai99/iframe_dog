=== Plugin Name ===
Contributors: Carseason
Tags: video, player, iframe
Requires at least: 4.8
Tested up to: 4.9.6

== Description ==
[dog url="123.mp4,av=123456" name="01,bilibili"]

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/iframe_dog` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. No configuration is needed, enjoy it!

== Screenshots ==
Write the shortcode manually in your editor,
demo:[dog url="123.mp4,av=123456" name="01,bilibili"]

== Changelog ==

= 1.2.2 =
Built-in Dplayer,Increase bilibili av iframe,Beautify CSS

= 1.0 =
iframe_dog up!