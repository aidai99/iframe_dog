function iframedog(video_url){
    document.getElementById("iframe").innerHTML='<iframe src="'+video_url+'" frameborder="0" allowfullscreen="" scrolling="none"></iframe>'; 
}